AOS.init({
    duration: 1200
   });

   const animatedBox = document.querySelector('.animated-box');

   window.addEventListener('scroll', () => {
       const boxPosition = animatedBox.getBoundingClientRect().top;
       const windowHeight = window.innerHeight;

       // Trigger the animation when the box comes into view
       if (boxPosition < windowHeight && !animatedBox.classList.contains('visible')) {
           animatedBox.classList.add('visible');
       } else if (boxPosition >= windowHeight) {
           animatedBox.classList.remove('visible'); // Optional: Remove class if it goes out of view
       }
   });

   const animatedBox1 = document.querySelector('.work-anime');

   window.addEventListener('scroll', () => {
       const boxPosition = animatedBox1.getBoundingClientRect().top;
       const windowHeight = window.innerHeight;

       // Trigger the animation when the box comes into view
       if (boxPosition < windowHeight && boxPosition > 0) {
           animatedBox1.classList.add('visible');
       } else {
           animatedBox1.classList.remove('visible'); // Remove class to reset animation
       }
   });