
AOS.init({
    duration: 2500,
  })
  