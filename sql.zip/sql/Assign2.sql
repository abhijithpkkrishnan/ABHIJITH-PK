CREATE DATABASE assign2db;
CREATE TABLE UserDetails (
    UserId INT PRIMARY KEY IDENTITY(1,1),  
    username VARCHAR(255),
    User_Type INT CHECK (User_Type IN (1, 2))  
);


INSERT INTO UserDetails (username, User_Type) VALUES ('Sam', 1);
INSERT INTO UserDetails (username, User_Type) VALUES ('Mac', 2);
INSERT INTO UserDetails (username, User_Type) VALUES ('David', 2);
INSERT INTO UserDetails (username, User_Type) VALUES ('John', 1);

CREATE TABLE UserPersonalInfo (
    UserPersonalInfoId INT PRIMARY KEY IDENTITY(1,1),  -- Identity field
    UserId INT FOREIGN KEY REFERENCES UserDetails(UserId),  -- Foreign Key referencing UserDetails
    First_Name VARCHAR(255),
    Last_Name VARCHAR(255),
    Email_Id VARCHAR(255),
    DOB DATETIME,
    Address VARCHAR(MAX),
    City VARCHAR(MAX),
    State VARCHAR(MAX),
    Country VARCHAR(MAX),
    Salary DECIMAL(18,2),
    DOJ VARCHAR(MAX) 
);

SET IDENTITY_INSERT UserPersonalInfo OFF;

INSERT INTO UserPersonalInfo (UserId, First_Name, Last_Name, Email_Id, DOB, Address, City, State, Country, Salary, DOJ)
VALUES 
(1, 'Sam', 'Samuel', 'samuel@123.com', '1990-01-01', '123 Main St', 'CityA', 'StateA', 'CountryA', 50000.00, '2020-01-15'),
(2, 'Mac', 'Jason', 'jason@123.com', '1985-05-05', '456 Elm St', 'CityB', 'StateB', 'CountryB', 60000.00, '2019-05-23'),
(3, 'David', 'Johnson', 'johnson@123.com', '1992-03-03', '789 Oak St', 'CityC', 'StateC', 'CountryC', 55000.00, '2021-11-30'),
(4, 'John', 'Matthew', 'matthew@123.com', '1988-07-07', '321 Pine St', 'CityD', 'StateD', 'CountryD', 70000.00, '2018-01-01');

SELECT * FROM UserDetails;
SELECT * FROM UserPersonalInfo;

------1-------------
SELECT * FROM UserDetails 
WHERE User_Type = 1;

---------2-------------
UPDATE UserPersonalInfo
SET Salary = 20000
WHERE DOJ >'01/01/2008';

------3---------------
CREATE TABLE CopiedPersonalInfo (
    UserPersonalInfoId INT PRIMARY KEY IDENTITY(1,1), 
    UserId INT FOREIGN KEY REFERENCES UserDetails(UserId),  
    Last_Name VARCHAR(255),
    Email_Id VARCHAR(255),
    DOB DATETIME,
    Address VARCHAR(MAX),
    City VARCHAR(MAX),
    State VARCHAR(MAX),
    Country VARCHAR(MAX),
    Salary DECIMAL(18,2),
    DOJ VARCHAR(MAX) 
);

INSERT INTO CopiedPersonalInfo (UserId, First_Name, Last_Name, Email_Id, DOB, Address, City, State, Country, Salary, DOJ)
SELECT UserId, First_Name, Last_Name, Email_Id, DOB, Address, City, State, Country, Salary, DOJ
FROM UserPersonalInfo;

----------------4---------------

SELECT * 
FROM UserPersonalInfo, UserDetails
WHERE UserPersonalInfo.Salary > (SELECT MAX(UserPersonalInfo.Salary) FROM UserPersonalInfo,UserDetails 
WHERE UserDetails.User_Type=1 AND UserDetails.UserId = UserPersonalInfo.UserId);

-----------------5---------------
SELECT UD.User_Type, AVG(UP.Salary) AS Average_Salary
FROM UserPersonalInfo UP
JOIN UserDetails UD ON UP.UserId = UD.UserId
GROUP BY UD.User_Type;

-----------6-------------------
SELECT UserPersonalInfoId,First_Name, Last_Name, Salary
from UserPersonalInfo
where Salary in((SELECT MIN(Salary) FROM UserPersonalInfo),(SELECT MAX(Salary) FROM UserPersonalInfo));

------------7---------------
SELECT 
    UserId,
    First_Name,
    Last_Name,
    Salary,
    Salary * 0.50 AS DA,
    Salary * 0.05 AS Professional_Tax,
    Salary + (Salary * 0.50) - (Salary * 0.05) AS Net_Salary
FROM UserPersonalInfo;

-----------------8------------------
Alter table UserDetails
Alter column username varchar(50);
-----------9-------------------
Alter table UserPersonalInfo
add Age int;
---------------10------------
ALTER TABLE UserPersonalInfo
ADD user_status INT; 

ALTER TABLE UserPersonalInfo
DROP COLUMN user_status;
----------11--------------
UPDATE UserPersonalInfo
SET Age = DATEDIFF(YEAR,DOB,GETDATE());

SELECT * FROM UserPersonalInfo;
------------12------------------
DELETE FROM UserPersonalInfo
WHERE user_status = 2;

----------------Stored Procedures-------------------

------------A--------------
CREATE PROC displayUserDetails
as
begin
SELECT * FROM UserDetails
END

displayUserDetails

---------B------------
CREATE PROC displayUserPersonalInfo
as
begin
SELECT * FROM UserPersonalInfo
END

 displayUserPersonalInfo

 -----------C-----------------

CREATE PROC AddUserDetails(
@UserName VARCHAR(20), 
@UserType INT
)
AS
BEGIN
INSERT INTO UserDetails(username,User_Type) VALUES
(@UserName , @UserType)
END

AddUserDetails 'Kiran',2

--------------D------------
CREATE PROCEDURE AddPersonalInfo
    @UserId INT,
    @FirstName VARCHAR(255),
    @LastName VARCHAR(255),
    @EmailId VARCHAR(255),
    @DOB DATETIME,
    @Address VARCHAR(MAX),
    @City VARCHAR(MAX),
    @State VARCHAR(MAX),
    @Country VARCHAR(MAX),
    @Salary DECIMAL(18,2),
    @DOJ VARCHAR(MAX),
    @UserPersonalInfoId INT OUTPUT 
AS
BEGIN
    
    INSERT INTO UserPersonalInfo (UserId, First_Name, Last_Name, Email_Id, DOB, Address, City, State, Country, Salary, DOJ)
    VALUES (@UserId, @FirstName, @LastName, @EmailId, @DOB, @Address, @City, @State, @Country, @Salary, @DOJ);

    SET @UserPersonalInfoId = SCOPE_IDENTITY();  
END;

---------------E---------------
CREATE PROC UpdatePersonalInfo(
	@FirstName VARCHAR(255),
    @LastName VARCHAR(255),
    @EmailId VARCHAR(255),
    @DOB DATETIME,
	@UserPersonalInfoId INT
	)
AS
BEGIN
UPDATE UserPersonalInfo
SET 
First_Name =@FirstName,
Last_Name = @LastName,
Email_Id = @EmailId,
DOB = @DOB
WHERE UserPersonalInfoId = @UserPersonalInfoId
END
------------------F-----------------
CREATE PROCEDURE UpdateSalOnExp
AS
BEGIN
    
    UPDATE UserPersonalInfo
    SET Salary = 
        CASE 
            WHEN DATEDIFF(YEAR, CONVERT(DATETIME, DOJ, 101), GETDATE()) > 3 THEN Salary * 1.20  
            ELSE Salary * 1.10  
        END;
END;
-------------------G-------------------
CREATE PROC DisplayExpName
AS
BEGIN
SELECT First_Name , DATEDIFF(YEAR,DOJ,GETDATE()) as Experience FROM UserPersonalInfo
END

DisplayExpName
---------------------------------
ALTER TABLE UserPersonalInfo
alter column DOJ datetime;