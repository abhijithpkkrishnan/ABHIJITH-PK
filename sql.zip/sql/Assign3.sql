create database assign4db;
CREATE TABLE Product (
    Product_id INT PRIMARY KEY IDENTITY(1,1),  
    Product_code VARCHAR(10),
    Product_Name VARCHAR(255),
    Product_Desc VARCHAR(255),
    Manufacturer VARCHAR(255),
    Unit_Price DECIMAL(9, 2),
    Units_In_Stock INT
);

CREATE TABLE Customer (
    Customer_id INT PRIMARY KEY IDENTITY(1,1),  -- Identity field for auto-incrementing
    CustomerName VARCHAR(255),
    Address VARCHAR(255),
    ContactNumber VARCHAR(255),
    CompanyName VARCHAR(255)
);
CREATE TABLE Orders (
    Orders_id INT PRIMARY KEY IDENTITY(1,1),  
    Customer_id INT,                           
    Product_id INT,                           
    Units_Ordered INT,
    Order_Date DATETIME,
    FOREIGN KEY (Customer_id) REFERENCES Customer(Customer_id),
    FOREIGN KEY (Product_id) REFERENCES Product(Product_id)
);
INSERT INTO Product (Product_code, Product_Name, Product_Desc, Manufacturer, Unit_Price, Units_In_Stock) VALUES
('P001', 'Detergent Powder', 'Washing powder for clothes', 'Hindustan Lever Limited', 150, 100),
('P002', 'Dishwash Liquid', 'Liquid for washing dishes', 'Hindustan Lever Limited', 200, 50),
('P003', 'Shampoo', 'Hair cleaning shampoo', 'Procter & Gamble', 250, 75),
('P004', 'Toothpaste', 'Fluoride toothpaste', 'Colgate-Palmolive', 100, 200),
('P005', 'Soap', 'Bathing soap', 'Hindustan Lever Limited', 50, 0);

INSERT INTO Customer (CustomerName, Address, ContactNumber, CompanyName) VALUES
('John Doe', '123 Elm St, Springfield', '555-1234', 'Doe Enterprises'),
('Jane Smith', '456 Oak St, Springfield', '555-5678', 'Smith LLC'),
('Alice Johnson', '789 Pine St, Springfield', '555-8765', 'Johnson Corp'),
('Bob Brown', '321 Maple St, Springfield', '555-4321', 'Brown Industries'),
('Charlie White', '654 Cedar St, Springfield', '555-6789', 'White & Co.');

INSERT INTO Orders (Customer_id, Product_id, Units_Ordered, Order_Date) VALUES
(1, 1, 5, '2023-09-15'),
(1, 2, 3, '2023-09-20'),
(2, 1, 12, '2023-09-25'),
(3, 3, 7, '2023-08-30'),
(4, 4, 2, '2023-09-10');

SELECT * FROM Product;
SELECT * FROM Customer;
SELECT * FROM Orders;

------------A--------------
SELECT * FROM Product;
------------B---------------
SELECT * FROM Product 
WHERE Manufacturer = 'Hindustan Lever Limited';
--------------C--------------
SELECT p.Product_Name, c.CustomerName, c.CompanyName, o.Order_Date
FROM Orders o
JOIN Product p ON o.Product_id = p.Product_id
JOIN Customer c ON o.Customer_id = c.Customer_id
WHERE o.Order_Date >= DATEADD(MONTH,-1,GETDATE());
------------------D----------
SELECT c.CustomerName, c.CompanyName, SUM(o.Units_Ordered) AS TotalUnitsOrdered
FROM Customer c
JOIN Orders o ON c.Customer_id = o.Customer_id
GROUP BY c.Customer_id, c.CustomerName, c.CompanyName
HAVING SUM(o.Units_Ordered) > 10
ORDER BY TotalUnitsOrdered DESC;
-------------------E--------------------------
CREATE TABLE copyTable
(ProductName VARCHAR(20),
CustomerName VARCHAR(20),
CompanyName VARCHAR(20),
OrderDate DATETIME
);

INSERT INTO copyTable(ProductName,CustomerName,CompanyName,OrderDate) 
SELECT P.Product_Name, c.CustomerName, c.CompanyName, o.Order_Date
FROM Orders o,Customer c, Product p
WHERE c.Customer_id = o.Customer_id AND o.Product_id = p.Product_id;

SELECT * FROM copyTable;
--------------F-----------------
SELECT AVG(Unit_Price) 
FROM Product
WHERE Manufacturer = 'Hindustan Lever Limited';

-------------G----------------
SELECT MAX(Unit_Price) minPrice, MIN(Unit_Price) maxPrice
FROM Product
WHERE Manufacturer = 'Hindustan Lever Limited';
--------------------H-------------
ALTER TABLE Orders
add Total_Price DECIMAL(10,2);
-------------I-----------------
UPDATE Orders
SET Total_Price = Units_Ordered * (SELECT Unit_Price FROM Product  WHERE Orders.Product_id = Product.Product_id); 
--------------------J-----------------------
ALTER TABLE Orders
DROP COLUMN Total_Price;

-----------K-----------
DELETE FROM Product
WHERE Units_In_Stock = 0;
------L-----------
ALTER TABLE CUSTOMER 
ALTER COLUMN CompanyName VARCHAR(125);
------------M--------
SELECT CustomerName, CompanyName, SUM(o.Units_Ordered * p.Unit_Price) AS totalSum 
FROM Customer c, Product p, Orders o
WHERE c.Customer_id = o.Customer_id AND p.Product_id = o.Product_id
GROUP BY c.Customer_id,c.CustomerName, c.CompanyName
HAVING SUM(o.Units_Ordered * p.Unit_Price) < 5000;

--------------N-----------
SELECT * 
FROM Customer,Orders
WHERE Orders_id = (SELECT COUNT(Customer_id) FROM Orders) AND Orders.Customer_id = Customer.Customer_id;

SELECT Customer.Customer_id, Customer.CustomerName,Customer.CompanyName, COUNT(Orders.Customer_id) totalOrders
FROM Customer,Orders
WHERE Customer.Customer_id = Orders.Customer_id
GROUP BY Customer.Customer_id, Customer.CustomerName, Customer.CompanyName;

--------STORED PROCEDURES-------------
------------A-----------
CREATE PROC viewDetails
AS
BEGIN
SELECT Product.Product_Name,Customer.CustomerName, Customer.CompanyName, Orders.Order_Date
FROM Customer,Product,Orders
WHERE Customer.Customer_id = Orders.Customer_id AND Orders.Product_id = Product.Product_id;
END

viewDetails
---------B----------
CREATE PROC insertDetailInOrder
(@customerid INT,
@productid INT, 
@unitsordered INT,
@orderdate DATETIME)
AS
BEGIN
INSERT INTO Orders(Customer_id,Product_id,Units_Ordered,Order_Date)
VALUES(@customerid,@productid,@unitsordered,@orderdate)
END

---------------C--------------
CREATE PROC UpdateDetailsProduct
(@productid INT,
@unitsinstock INT)
AS
BEGIN
UPDATE Product
SET 
Units_In_Stock = @unitsinstock
WHERE Product_id = @productid;
END
----------------D-----------------
CREATE PROC UpdateUnitPrice
AS
BEGIN
IF((SELECT PRODUCT.Units_In_Stock  FROM Product) > 1000)
UPDATE Product
SET Unit_Price = Unit_Price - (Unit_Price*5)/100
WHERE Product_id=1
ELSE
UPDATE Product
SET Unit_Price = Unit_Price - (Unit_Price*10)/100
WHERE Product_id=1
END
----------------------------------------------
CREATE PROC UpdateUnitPriceAll
AS
DECLARE @unitInStock INT
DECLARE @productid INT

SELECT @productid = PRODUCT.Product_id , @unitInStock = Product.Units_In_Stock
FROM Product
IF(@unitInStock>1000)
BEGIN
UPDATE Product
SET Unit_Price = Unit_Price - (Unit_Price*10)/100
WHERE Product_id=@productid
END
ELSE
BEGIN
UPDATE Product
SET Unit_Price = Unit_Price - (Unit_Price*5)/100
WHERE Product_id=@productid
END

UpdateUnitPriceAll



