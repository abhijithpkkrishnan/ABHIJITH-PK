create  database assignment1db;
create  table Department_Master(
 department_id int primary key,
 department_code varchar(10),
 department_name varchar(255),
 department_location varchar(255),
 department_Status bit
 );
 select * from Department_Master;
 insert into Department_Master(department_code,department_name,department_location,department_Status)values 
 ('IT','Information Tech','Mysore',1),
 ('MAR','Marketing','Mysore',1),
 ('HR','Human Resourse','Mysore',1),
 ('DEV','Development','Mysore',1);
 
 
 insert into Department_Master(department_code,department_name,department_location,department_Status)values 
 ('RAM','Human Resourse', 'Mysore',-3);

 SELECT * FROM Department_Master;


 CREATE TABLE employee_details(
 staff_id int primary key identity,
 first_name varchar(50),
 last_name varchar(50),
 mail_id varchar(100),
 reporting_to int,
 department_id int foreign key references Department_Master(department_id),
 phone varchar(50),
 mobile_number varchar(50),
 employed_country varchar(50),
 date_of_birth datetime,
 date_of_joining datetime,
 city varchar(20),
 salary numeric(10,2)
 );

 select * from employee_details;

set identity_insert employee_details off;

insert into employee_details(first_name,last_name,reporting_to,department_id) values
('Abhishek','Kumar',1,1),
('Arjun','Varma',1,1),
('Nihir','A',1,1),
('Sohail','Z',3,2),
('Ravi','R',3,2);

-------------------1----------------
select * 
from employee_details,Department_Master 
where Department_Master.department_name = 'Marketing' and employee_details.department_id = Department_Master.department_id;
-------------2------------------------
update employee_details
set date_of_joining= '01/04/2005'
where staff_id = 5;

SELECT * FROM employee_details;

update employee_details
set salary = 10000
where date_of_joining > '01/01/2008';
------------3-----------------------
CREATE TABLE employee(
 staff_id int primary key identity,
 first_name varchar(50),
 last_name varchar(50),
 mail_id varchar(100),
 reporting_to int,
 department_id int foreign key references Department_Master(department_id),
 phone varchar(50),
 mobile_number varchar(50),
 employed_country varchar(50),
 date_of_birth datetime,
 date_of_joining datetime,
 city varchar(20),
 salary numeric(10,2)
 );

 insert into employee(first_name,last_name,reporting_to,department_id)
 select first_name,last_name,reporting_to,department_id
 from employee_details;

 select *  from employee;
 select * from employee_details


 ----------4----------------
 update employee_details
 set salary=50000
 where staff_id = 2

 select * from employee_details 
 where salary >(select max(salary) from employee_details,Department_Master
 where Department_Master.department_name='Marketing' and Department_Master.department_id = employee_details.department_id);
 -------------5--------------------------
 
 select department_code, department_name, avg(salary)
 from Department_Master,employee_details
 where Department_Master.department_id = employee_details.department_id
 group by 
 Department_Master.department_name,
 Department_Master.department_code;
 
 -----------------------6--------------------
 select staff_id, first_name, last_name, salary
 from employee_details where salary in ((select max(salary) from employee_details),(select min(salary) from employee_details));

 -----------------------7----------------------------

 select (salary * 50)/100  DA, (salary*5)/100 professional_tax, (salary + (salary * 50)/100 - (salary*5)/100) net_salary 
 from employee_details;

 ---------------------8---------------------

 select * from Department_Master; 
 select * from employee_details;

 select department_name 
 from Department_Master, employee_details
 where Department_Master.department_id= employee_details.department_id
 group by department_name
 having count(employee_details.department_id)>1;

 SELECT d.department_name FROM  employee_details e
 JOIN Department_Master d ON d.department_id = e.department_id 
 GROUP BY department_name
 HAVING COUNT(d.department_name)>1;

 

 -------------------9----------------------
 Alter table Department_Master 
 alter column department_name varchar(40);

------------------10------------------------
Alter table Department_Master
add department_manager varchar(20);

-----------------11---------------------
Alter table Department_Master
drop column department_manager;

select * from Department_Master;

-----------------12-------------
Update employee_details
set salary= salary + 1000
where date_of_joining between '01/01/2005' and '01/01/2010';

select* from employee_details

--------------13---------------

delete from Department_Master
where department_Status = 2;

--------------14-----------------
Update Department_Master
set department_manager = 'Arya'
where department_id =4;

select first_name, last_name, department_manager
from Department_Master, employee_details
where Department_Master.department_id = employee_details.department_id;

----------------------15----------------

select * from employee_details;
select * from Department_Master;

update employee_details
set city = 'palakkad'
where staff_id = 5;

select e.first_name ,e.last_name from
employee_details e , Department_Master d
where e.city = d.department_location and e.department_id = d.department_id;

-----------Stoed Procedures---------------------

------------a-----------
create proc detailsAll
as 
Begin
 select * from employee_details
End

detailsAll

-----b------------
create proc detailsAll_Dept
as 
Begin
 select * from Department_Master
End

detailsAll_Dept

-----------------c---------------
create proc new_dept(
@deptCode varchar(20),
@deptName varchar(20),
@deptLocation varchar(20),
@status bit)
as
begin
 insert into Department_Master(department_code, department_name, department_location, department_Status) values(@deptCode, @deptName, @deptLocation, @status)
End

EXEC new_dept 'IT', 'Development', 'Mysore', 1;
---------------d--------------------------
create proc new_emp(
@firstname varchar(20),
@lastname varchar(20),
@mailed varchar(40), 
@reportingto int, 
@department_id int, 
@phone varchar(20), 
@mobilenumber varchar(20),
@employedcountry varchar(20),
@dateofjoining datetime,
@city varchar(20),
@salary numeric(10,2)
)
as
begin
insert into employee_details
(first_name,
 last_name,
 mail_id,
 reporting_to,
 department_id,
 phone,
 mobile_number,
 employed_country,
 date_of_joining,
 city,
 salary)
 values
 (
@firstname,
@lastname,
@mailed, 
@reportingto, 
@department_id, 
@phone, 
@mobilenumber,
@employedcountry,
@dateofjoining,
@city,
@salary
)
select staff_id from employee_details;
end

new_emp 'sam', 'S', '',1,2,'009090','392974020','India','01/01/2009','Bangalore',10000

------------e----------------------
create proc updateEmp 
(
@staffid int,
@firstname varchar(20), 
@lastname varchar(20),
@mailed varchar(20),
@reportingto int,
@department_id int,
@phone varchar(20),
@mobilenumber varchar(20),
@employedcountry varchar(20),
@dateofjoining datetime
,@city varchar(20),
@salary numeric(10,2)
)
as
begin
update employee_details
set 
first_name = @firstname,
last_name = @lastname,
mail_id =@mailed,
reporting_to=@reportingto,
department_id=@department_id,
phone = @phone,
mobile_number=@mobilenumber,
employed_country =@employedcountry,
date_of_joining =@dateofjoining,
city =@city,
salary= @salary
where staff_id = @staffid;
end

updateEmp 1,'Devu','P','devu@123',1,2,'121331','113133','India','01/08/2009','Chennai',30000

select * from employee_details

create proc updateSal(
@staffid int,
@dateofjoining datetime,
@salary numeric(10,2)
)
as
if(year(@dateofjoining)<2007)
begin
update employee_details
set salary = salary + (salary*20)/100
where staff_id = @staffid
end
else
begin
update employee_details
set salary = salary + (salary*10)/100
where staff_id = @staffid
end

-------------g----------------------
CREATE PROCEDURE showExp
AS
BEGIN
    SELECT 
        YEAR(GETDATE()) - YEAR(date_of_joining) AS experience, 
        first_name
    FROM 
        employee_details;
END;

showExp
------------------------------test---------------
CREATE PROC UpdateSalary
AS
begin
IF((SELECT YEAR(GETDATE()) - YEAR(date_of_joining) AS experience FROM employee_details WHERE employee_details.staff_id =1) >3)
UPDATE employee_details
SET salary = salary + salary*0.10
end


DROP PROC UpdateSalary