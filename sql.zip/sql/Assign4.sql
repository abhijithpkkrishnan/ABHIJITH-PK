create database assign3db;
CREATE TABLE Vendor (
    VendorID INT NOT NULL PRIMARY KEY,
    AccountNumber VARCHAR(15),
    CompanyName VARCHAR(50) NOT NULL,
    Location VARCHAR(50) NOT NULL,
    CreditRating TINYINT NOT NULL CHECK (CreditRating IN (1, 2, 3, 4, 5)),
    ActiveFlag BIT NOT NULL CHECK (ActiveFlag IN (0, 1)),
    PurchasingWebServiceURL VARCHAR(255)
);
CREATE TABLE ProductInventory (
    ProductInventoryID INT NOT NULL PRIMARY KEY,
    ProductID VARCHAR(15),
    ProductName VARCHAR(50) NOT NULL,
    Location VARCHAR(50) NOT NULL,
    Quantity INT,
    UnitPrice DECIMAL(9, 2)
);
CREATE TABLE Sales (
    SalesID INT NOT NULL PRIMARY KEY,
    ProductID INT,
    VendorID INT,
    SalesDate DATETIME,
    Quantity INT
	FOREIGN KEY (ProductID) REFERENCES ProductInventory(ProductInventoryID),
    FOREIGN KEY (VendorID) REFERENCES Vendor(VendorID)
);

INSERT INTO Vendor (VendorID, AccountNumber, CompanyName, Location, CreditRating, ActiveFlag, PurchasingWebServiceURL) VALUES
(1, 'ACC001', 'National Sales Corp', 'New York', 2, 1, 'national-sales.com'),
(2, 'ACC002', 'International Merchandise', 'Los Angeles', 3, 1, 'international-merch.com'),
(3, 'ACC003', 'Local Supplies', 'Chicago', 4, 1, 'local-supplies.com'),
(4, 'ACC004', 'Global Traders', 'Houston', 1, 1, 'global-traders.com'),
(5, 'ACC005', 'Quality Goods', 'Phoenix', 5, 1, 'quality-goods.com'),
(6, 'ACC006', 'Fast Supplies', 'Philadelphia', 3, 1, 'fast-supplies.com'),
(7, 'ACC007', 'Reliable Vendors', 'San Antonio', 2, 1, 'reliable-vendors.com'),
(8, 'ACC008', 'Eco-Friendly Products', 'San Diego', 4, 1, 'eco-friendly.com'),
(9, 'ACC009', 'Tech Innovations', 'Dallas', 1, 1, 'tech-innovations.com'),
(10, 'ACC010', 'Home Essentials', 'San Jose', 3, 1, 'home-essentials.com');

INSERT INTO ProductInventory (ProductInventoryID, ProductID, ProductName, Location, Quantity, UnitPrice) VALUES
(1, 'P001', 'Laptop', 'Mysore', 50, 999),
(2, 'P002', 'Smartphone', 'Mysore', 100, 450),
(3, 'P003', 'Tablet', 'Mysore', 75, 300),
(4, 'P004', 'Monitor', 'Bangalore', 30, 199),
(5, 'P005', 'Keyboard', 'Mysore', 200, 50),
(6, 'P006', 'Mouse', 'Mysore', 150, 20),
(7, 'P007', 'Printer', 'Mysore', 25, 150),
(8, 'P008', 'Webcam', 'Mysore', 60, 89.99),
(9, 'P009', 'Headphones', 'Mysore', 80, 60),
(10, 'P010', 'External Hard Drive', 'Bangalore', 40, 130);

INSERT INTO Sales (SalesID, ProductID, VendorID, SalesDate, Quantity) VALUES
(1, 1, 1, '2011-09-01', 10),
(2, 2, 2, '2011-08-15', 20),
(3, 3, 1, '2011-08-20', 15),
(4, 4, 3, '2011-08-25', 5),
(5, 5, 4, '2011-09-01', 30),
(6, 6, 5, '2011-08-30', 25),
(7, 7, 2, '2011-08-10', 10),
(8, 8, 6, '2011-08-05', 12),
(9, 9, 7, '2011-08-12', 18),
(10, 10, 8, '2011-09-01', 8);
;
----------------A--------------
SELECT * FROM Vendor;
------------B------------
SELECT *FROM ProductInventory;
SELECT * FROM Vendor;
SELECT * FROM Sales;
-----------------C------------------
SELECT pi.*
FROM ProductInventory pi
JOIN Sales s ON pi.ProductInventoryID = s.ProductID
JOIN Vendor v ON s.VendorID = v.VendorID
WHERE s.SalesDate = '2011-09-01' AND v.CompanyName = 'National Sales Corp';

-------------------D----------------------
SELECT COUNT(ProductInventoryID) FROM ProductInventory pi,Vendor v,Sales s
WHERE v.CompanyName='International Merchandise' AND s.SalesDate BETWEEN '2011-08-01' AND '2011-08-31' AND s.ProductID = pi.ProductInventoryID AND v.VendorID=s.VendorID;
 ------------------E-----------------

SELECT * FROM Vendor v,Sales s
WHERE s.Quantity >(SELECT AVG(Quantity) FROM Sales) AND s.VendorID=v.VendorID;
--------------------F--------------------
SELECT AVG(UnitPrice) FROM ProductInventory
WHERE Location='Mysore';
--------------------G-------------------
SELECT ProductName FROM ProductInventory
WHERE Quantity IN((SELECT MAX(Quantity) FROM ProductInventory),(SELECT MIN(Quantity) FROM ProductInventory)) AND Location='Mysore';
--------------------H-------------------
ALTER TABLE Sales
ADD Shipped BIT CHECK (Shipped IN(0,1));

SELECT * FROM Sales
----------I----------------------
UPDATE Sales
SET Shipped = 1
WHERE SalesDate < GETDATE();

----------------J---------------
DELETE FROM Vendor
WHERE VendorID NOT IN (SELECT DISTINCT VendorID FROM Sales);
----------------K----------------
ALTER TABLE Vendor
DROP COLUMN PurchasingWebServiceURL;
------------------L----------------
ALTER TABLE ProductInventory
ALTER COLUMN Location VARCHAR(255);
--------------------M---------------------
SELECT * FROM ProductInventory pi,Vendor v,Sales s
WHERE pi.Location = v.Location  AND pi.ProductInventoryID = s.ProductID AND v.VendorID = s.VendorID;

---------------STORED PROCEDURES-----------------------
---------------A--------------
CREATE PROC displayDetails
as
BEGIN
SELECT ProductName,CompanyName,SalesDate
FROM ProductInventory pi,Vendor v,Sales s
WHERE pi.ProductInventoryID = s.ProductID AND v.VendorID = s.VendorID
ORDER BY s.SalesDate DESC;
END

displayDetails
-------------B------------------
CREATE PROC insertDetails(
@vendorid INT, 
@productid INT, 
@quantity INT, 
@saledate DATETIME
)
AS
BEGIN
INSERT INTO Sales(VendorID,ProductID,Quantity,SalesDate) VALUES
(@vendorid,@productid,@quantity,@saledate);
END
-------------------C------------------
CREATE PROC updateDetails(
@ProductInventoryID INT, 
@productid INT, 
@Quantity INT,
@UnitPrice DECIMAL(9, 2)
)
AS
BEGIN
UPDATE  ProductInventory
SET ProductID = @productid,
Quantity = @Quantity,
UnitPrice = @UnitPrice
WHERE ProductInventoryID = @ProductInventoryID;
END
------------------D---------------------

CREATE PROCEDURE UpdateVendorCreditRating
AS
BEGIN
    DECLARE @VendorID INT;
    DECLARE @TotalSalesQuantity INT;


    SELECT TOP 1 @VendorID = s.VendorID, @TotalSalesQuantity = SUM(s.Quantity)
    FROM Sales s
    WHERE s.SalesDate >= '2011-08-01' AND s.SalesDate < '2011-09-01'
    GROUP BY s.VendorID
    ORDER BY SUM(s.Quantity) DESC;

   
    IF @VendorID IS NOT NULL
    BEGIN
       
        IF @TotalSalesQuantity > 10000
        BEGIN
            UPDATE Vendor
            SET CreditRating = 1 
            WHERE VendorID = @VendorID;
        END
        ELSE IF @TotalSalesQuantity > 5000
        BEGIN
            UPDATE Vendor
            SET CreditRating = 2
            WHERE VendorID = @VendorID;
        END
        ELSE IF @TotalSalesQuantity > 1000
        BEGIN
            UPDATE Vendor
            SET CreditRating = 3 
            WHERE VendorID = @VendorID;
        END
        ELSE IF @TotalSalesQuantity > 500
        BEGIN
            UPDATE Vendor
            SET CreditRating = 4
            WHERE VendorID = @VendorID;
        END
        ELSE
        BEGIN
            UPDATE Vendor
            SET CreditRating = 5 
            WHERE VendorID = @VendorID;
        END
    END
END;
