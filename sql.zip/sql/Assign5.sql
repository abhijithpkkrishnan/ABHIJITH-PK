CREATE DATABASE assign5db;
CREATE TABLE MANUFACTURERS (
    maname VARCHAR(50),
    location VARCHAR(50)
);

CREATE TABLE MODELS (
    mid INT PRIMARY KEY,
    maname VARCHAR(50),
    model VARCHAR(50)
);

CREATE TABLE CARS (
    cid INT PRIMARY KEY,
    mid INT,
    cyear INT,
    FOREIGN KEY (mid) REFERENCES MODELS(mid)
);

CREATE TABLE BUYERS (
    bid INT PRIMARY KEY,
    bname VARCHAR(50),
    bcity VARCHAR(50),
    age INT
);

CREATE TABLE SALESPEOPLE (
    sid INT PRIMARY KEY,
    sname VARCHAR(50),
    years_employed INT
);

CREATE TABLE TRANSACTIONS (
    bid INT,
    cid INT,
    sid INT,
    amount DECIMAL(10, 2),
    month INT,
    day INT,
    year INT,
    FOREIGN KEY (bid) REFERENCES BUYERS(bid),
    FOREIGN KEY (cid) REFERENCES CARS(cid),
    FOREIGN KEY (sid) REFERENCES SALESPEOPLE(sid)
);


INSERT INTO MANUFACTURERS (maname, location) VALUES
('Ford', 'USA'),
('Toyota', 'Japan'),
('Honda', 'Japan');


INSERT INTO MODELS (mid, maname, model) VALUES
(1, 'Ford', 'Mustang'),
(2, 'Ford', 'F-150'),
(3, 'Toyota', 'Camry'),
(4, 'Honda', 'Civic');


INSERT INTO CARS (cid, mid, cyear) VALUES
(1, 1, 2020),  
(2, 2, 2019), 
(3, 3, 2021),  
(4, 4, 2022);  


INSERT INTO BUYERS (bid, bname, bcity, age) VALUES
(1, 'Alice', 'New York', 30),
(2, 'Bob', 'Los Angeles', 25),
(3, 'Charlie', 'Chicago', 35),
(4, 'David', 'Houston', 40);


INSERT INTO SALESPEOPLE (sid, sname, years_employed) VALUES
(1, 'Eve', 5),
(2, 'Frank', 12),
(3, 'Grace', 8),
(4, 'Heidi', 3);


INSERT INTO TRANSACTIONS (bid, cid, sid, amount, month, day, year) VALUES
(1, 1, 1, 9500.00, 5, 15, 2020), 
(2, 3, 2, 20000.00, 6, 20, 2021),
(3, 2, 3, 15000.00, 7, 25, 2021), 
(4, 4, 4, 18000.00, 8, 30, 2022),
(1, 1, 1, 8000.00, 9, 10, 1997), 
(2, 3, 2, 12000.00, 10, 5, 1997),  
(3, 2, 3, 11000.00, 11, 15, 1997); 

SELECT * FROM MANUFACTURERS
SELECT * FROM MODELS
SELECT * FROM BUYERS
SELECT * FROM CARS
SELECT * FROM SALESPEOPLE
SELECT * FROM TRANSACTIONS
----------1-------------
SELECT distinct bname, bcity 
FROM BUYERS b , TRANSACTIONS t , CARS c, MANUFACTURERS man , MODELS m
WHERE t.amount < 10000 AND  m.maname = 'Ford' AND m.model = 'Mustang' AND c.cid = t.cid AND b.bid = t.bid AND c.mid = m.mid;

-----------2-----------
SELECT s.sid 
FROM SALESPEOPLE s,TRANSACTIONS t , CARS c ,MODELS m
WHERE t.cid = (SELECT m.mid FROM CARS c, MODELS m  WHERE m.mid = c.mid AND m.maname = 'Ford' AND m.maname = 'Toyota') AND c.cyear = 2020 AND t.cid = c.cid;   

SELECT DISTINCT t.sid
FROM TRANSACTIONS t
JOIN CARS c ON t.cid = c.cid
JOIN MODELS m ON c.mid = m.mid
WHERE t.year = 1997 AND (m.maname = 'Ford' OR m.maname = 'Toyota')
GROUP BY t.sid
HAVING COUNT(DISTINCT m.maname) = 2;

-------------3--------------
SELECT DISTINCT t.sid
FROM TRANSACTIONS t
JOIN CARS c ON t.cid = c.cid
JOIN MODELS m ON c.mid = m.mid
GROUP BY t.sid
HAVING COUNT(DISTINCT m.maname) = (SELECT COUNT(DISTINCT maname) FROM MANUFACTURERS);

----------------4----------------
SELECT  DISTINCT sname FROM SALESPEOPLE s, TRANSACTIONS t
WHERE s.sid NOT IN (SELECT sid FROM TRANSACTIONS t WHERE t.year = 1997);
---------------5----------------------
SELECT TOP 1 s.sname, SUM(t.amount) totalSum  FROM SALESPEOPLE s ,TRANSACTIONS t 
WHERE t.sid = s.sid AND t.year = 1997
GROUP BY s.sid, s.sname
ORDER BY totalSum DESC;

-----------------6-------------
SELECT SALESPEOPLE.sname, AVG(TRANSACTIONS.amount) AS average_sales_amount
FROM SALESPEOPLE
JOIN TRANSACTIONS ON SALESPEOPLE.sid = TRANSACTIONS.sid
WHERE SALESPEOPLE.years_employed < 10
GROUP BY SALESPEOPLE.sid, SALESPEOPLE.sname
HAVING COUNT(TRANSACTIONS.cid) >= 50
ORDER BY average_sales_amount DESC;
----------ASSIGNMENT PART 2---------------------------
